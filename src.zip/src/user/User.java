package user;

public class User {
	
	private String uUserId;
	private String uUserPassword;
	private String uUserName;
	private String uUserPhone;
	private String uUserEmail;
	public String getuUserId() {
		return uUserId;
	}
	public void setuUserId(String uUserId) {
		this.uUserId = uUserId;
	}
	public String getuUserPassword() {
		return uUserPassword;
	}
	public void setuUserPassword(String uUserPassword) {
		this.uUserPassword = uUserPassword;
	}
	public String getuUserName() {
		return uUserName;
	}
	public void setuUserName(String uUserName) {
		this.uUserName = uUserName;
	}
	public String getuUserPhone() {
		return uUserPhone;
	}
	public void setuUserPhone(String uUserPhone) {
		this.uUserPhone = uUserPhone;
	}
	public String getuUserEmail() {
		return uUserEmail;
	}
	public void setuUserEmail(String uUserEmail) {
		this.uUserEmail = uUserEmail;
	}
	
	
}
